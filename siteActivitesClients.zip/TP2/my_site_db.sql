-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : jeu. 05 déc. 2024 à 14:41
-- Version du serveur : 9.1.0
-- Version de PHP : 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `my_site_db`
--

-- --------------------------------------------------------

--
-- Structure de la table `activity`
--

DROP TABLE IF EXISTS `activity`;
CREATE TABLE IF NOT EXISTS `activity` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_bin,
  `season` enum('été','automne','hiver','printemps') CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;

--
-- Déchargement des données de la table `activity`
--

INSERT INTO `activity` (`id`, `name`, `description`, `season`) VALUES
(1, 'Randonnée en montagne', 'Marche en pleine nature, généralement en montagne, pour profiter du paysage', 'printemps'),
(2, 'Yoga', 'Pratique physique et mentale favorisant la détente et la souplesse', 'automne'),
(3, 'Pêche', 'Activité de loisir qui consiste à attraper des poissons', 'été'),
(4, 'Kayak', 'Sport nautique pratiqué en canoë ou kayak sur des rivières ou lacs', 'été'),
(5, 'Capoeira', 'Art martial brésilien alliant danse, musique et acrobaties', 'hiver'),
(6, 'Golf', 'Sport de précision où l\'objectif est de frapper une balle dans des trous à l\'aide d\'un club', 'printemps'),
(7, 'Boxe', 'Sport de combat où deux personnes s’affrontent en utilisant leurs poings', 'automne'),
(8, 'Arts martiaux', 'Discipline qui regroupe plusieurs techniques de combat et d\'autodéfense', 'été'),
(9, 'Escalade', 'Sport consistant à grimper des parois rocheuses ou des murs d\'escalade', 'printemps'),
(10, 'Trekking', 'Randonnée de longue durée, souvent en milieu sauvage ou montagneux', 'hiver'),
(11, 'Randonnée en montagne', 'Marche en pleine nature, généralement en montagne, pour profiter du paysage.', 'printemps'),
(12, 'Yoga', 'Pratique physique et mentale favorisant la détente, la souplesse et l\'équilibre.', 'printemps'),
(13, 'Pêche', 'Activité de loisir qui consiste à attraper des poissons en utilisant une canne à pêche.', 'été'),
(14, 'Kayak', 'Sport nautique consistant à pagayer sur des rivières, lacs ou mers dans un petit bateau.', 'été'),
(15, 'Capoeira', 'Art martial brésilien combinant danse, acrobaties et musique, pratiqué souvent en groupe.', 'automne'),
(16, 'Golf', 'Sport de précision où l\'objectif est de frapper une balle avec un club pour la faire entrer dans un trou.', 'printemps'),
(17, 'Boxe', 'Sport de combat où deux personnes s\'affrontent en utilisant leurs poings, dans un ring.', 'automne'),
(18, 'Arts martiaux', 'Discipline englobant diverses techniques de combat et de défense personnelle.', 'hiver'),
(19, 'Escalade', 'Sport consistant à grimper des parois rocheuses ou des murs d\'escalade en salle.', 'printemps'),
(20, 'Trekking', 'Randonnée de longue durée, souvent sur des terrains difficiles ou montagneux.', 'hiver'),
(21, 'course de vitesse', 'parcourir la distance en peu de temps', 'automne');

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

DROP TABLE IF EXISTS `client`;
CREATE TABLE IF NOT EXISTS `client` (
  `id` int NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL,
  `lastname` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL,
  `sex` enum('masculin','feminin','autre') CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL,
  `age` int NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`id`, `firstname`, `lastname`, `sex`, `age`, `email`) VALUES
(1, 'Emmanuel', 'Nkwelle', 'masculin', 30, 'emmanuel.nkwelle@example.com'),
(2, 'Chantal', 'Mouelle', 'feminin', 25, 'chantal.mouelle@example.com'),
(3, 'Sylvain', 'Mefire', 'masculin', 28, 'sylvain.mefire@example.com'),
(4, 'Marthe', 'Mballa', 'feminin', 34, 'marthe.mballa@example.com'),
(5, 'Ali', 'Njoya', 'masculin', 40, 'ali.njoya@example.com'),
(6, 'Patricia', 'Ngongang', 'feminin', 29, 'patricia.ngongang@example.com'),
(7, 'Claudine', 'Fouda', 'feminin', 32, 'claudine.fouda@example.com'),
(8, 'François', 'Tchouangue', 'masculin', 38, 'francois.tchouangue@example.com'),
(9, 'Jean-Pierre', 'Zang', 'masculin', 27, 'jeanpierre.zang@example.com'),
(10, 'Brigitte', 'Ekoue', 'feminin', 36, 'brigitte.ekoue@example.com'),
(11, 'anaba', 'michel', 'masculin', 20, 'michelanaba@gmail.com');

-- --------------------------------------------------------

--
-- Structure de la table `subscription`
--

DROP TABLE IF EXISTS `subscription`;
CREATE TABLE IF NOT EXISTS `subscription` (
  `client_id` int NOT NULL,
  `activity_id` int NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`client_id`,`activity_id`),
  KEY `activity_id` (`activity_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;

--
-- Déchargement des données de la table `subscription`
--

INSERT INTO `subscription` (`client_id`, `activity_id`, `date`) VALUES
(1, 1, '2024-04-05'),
(2, 2, '2024-03-12'),
(3, 3, '2024-06-10'),
(4, 4, '2024-07-20'),
(5, 5, '2024-09-15'),
(6, 6, '2024-04-25'),
(7, 7, '2024-10-01'),
(8, 8, '2024-12-05'),
(9, 9, '2024-04-15'),
(10, 10, '2024-11-22');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
